#ifndef WORLDTREE_H
#define WORLDTREE_H

#include <QWidget>

class worldTree : public QWidget
{
  Q_OBJECT

  public:
  worldTree(QWidget *parent = 0);
};

#endif
