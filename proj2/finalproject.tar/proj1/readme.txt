Hello! This is my project.

You should be able to make everything by typing make. If that doesn't work, and you've got Qt installed on your computer, try typing the following series of commands:

qmake -project
qmake
make

The executable will be the same name as the folder that it's in.

I tried to make this on acl22, but I had some problems. The previous files are in tarball.tar, in case you have any trouble building and running it from this tarball. You should just be able to type ./proj1 and everything should work fine!

- Dylan
